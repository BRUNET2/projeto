import 'dart:async';
import 'package:sqlite/sqlite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'user_database.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
      )
    ''');
  }

  Future<int> registerUser(String name, String email, String password) async {
    Database db = await database;
    return await db.insert(
      'users',
      {
        'name': name,
        'email': email,
        'password': password,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<String, dynamic>?> getUser(String email, String password) async {
    Database db = await database;
    List<Map<String, dynamic>> result = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, password],
    );

    if (result.isNotEmpty) {
      return result.first;
    }
    return null;
  }
}

void main() async {
  DatabaseHelper dbHelper = DatabaseHelper();

  // Registrar um usuário
  int userId = await dbHelper.registerUser('Nome', 'email@example.com', 'senha123');
  print('Usuário registrado com id: $userId');

  // Obter um usuário pelo email e senha
  Map<String, dynamic>? user = await dbHelper.getUser('email@example.com', 'senha123');
  if (user != null) {
    print('Usuário encontrado: ${user['name']}');
  } else {
    print('Usuário não encontrado');
  }
}
