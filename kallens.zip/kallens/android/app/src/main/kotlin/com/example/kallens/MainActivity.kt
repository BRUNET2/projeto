package com.example.kallens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
